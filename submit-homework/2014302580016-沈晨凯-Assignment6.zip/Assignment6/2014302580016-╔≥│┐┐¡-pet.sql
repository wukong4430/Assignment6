﻿# Host: localhost  (Version: 5.5.40)
# Date: 2015-11-21 17:32:18
# Generator: MySQL-Front 5.3  (Build 4.120)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "pet"
#

CREATE TABLE if not exists `2014302580016_pet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `eat` varchar(255) NOT NULL DEFAULT '',
  `drink` varchar(255) NOT NULL DEFAULT '',
  `live` varchar(255) NOT NULL DEFAULT '',
  `hobby` varchar(255) NOT NULL DEFAULT '',
   `price` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

#
# Data for table "pet"
#

INSERT INTO `2014302580016_pet` VALUES (1,'dog','bone','water','ground','play',95.0),
(2,'cat','fish','milk','roof','hug',125.8),
(3,'turtle','fish,shrimp','sea water','sea water','bask',88.5),
(4,'parrot','nuts,seeds','water','tree','fly',155.9),
(5,'hamster','Sunflower seed','water','corner','eat',58.0),
(6,'squirrel','pine cone','water','tree hole,underground','play',120.0),
(7,'rabbit','carrot','water','grassland,underground','eat',70.5),
(8,'snake','mouse','water','hole','bask',100.0),
(9,'lizard','bug','water','tree','bask',77.5),
(10,'fish','aquatic plant','water','water','swim',49.9),
(11,'myna','earthworm','water','tree','fly',129.5),
(12,'canary','millet','water','tree','sing',150.0);
