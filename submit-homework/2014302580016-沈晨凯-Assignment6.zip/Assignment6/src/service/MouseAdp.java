package service;
 
import dao.*;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/**
 * 该类实现了鼠标点击接口
 * @author Anjail
 *
 */

public class MouseAdp implements MouseListener{

	public MouseAdp(){}
	
	public void mouseClicked(MouseEvent e) {
		/**鼠标点击事件(包括按下和弹起两个动作)处理方法.**/
		
		if(e.getSource().equals(StoreGUI.getLabel1())){
			new PetDetails("cat");
			StoreGUI.frame.setVisible(false);
		}
		if(e.getSource().equals(StoreGUI.getLabel2())){
		
			new PetDetails("dog");
			StoreGUI.frame.setVisible(false);
		}
		if(e.getSource().equals(StoreGUI.getLabel3())){
			
			new PetDetails("fish");
			StoreGUI.frame.setVisible(false);
		}
		if(e.getSource().equals(StoreGUI.getLabel4())){
			
			new PetDetails("rabbit");
			StoreGUI.frame.setVisible(false);
		}
		if(e.getSource().equals(StoreGUI.getLabel5())){
			
			new PetDetails("canary");
			StoreGUI.frame.setVisible(false);
		}
		if(e.getSource().equals(StoreGUI.getLabel6())){
			
			new PetDetails("parrot");
			StoreGUI.frame.setVisible(false);
		}
		if(e.getSource().equals(StoreGUI.getLabel7())){
			
			new PetDetails("lizard");
			StoreGUI.frame.setVisible(false);
		}
		if(e.getSource().equals(StoreGUI.getLabel8())){
			
			new PetDetails("turtle");
			StoreGUI.frame.setVisible(false);
		}
		if(e.getSource().equals(StoreGUI.getLabel9())){
			
			new PetDetails("hamster");
			StoreGUI.frame.setVisible(false);
		}
		if(e.getSource().equals(StoreGUI.getLabel10())){
			
			new PetDetails("snake");
			StoreGUI.frame.setVisible(false);
		}
		if(e.getSource().equals(StoreGUI.getLabel11())){
			
			new PetDetails("squirrel");
			StoreGUI.frame.setVisible(false);
		}
		if(e.getSource().equals(StoreGUI.getLabel12())){
			
			new PetDetails("myna");
			StoreGUI.frame.setVisible(false);
		}
		
		}

		public void mouseEntered(MouseEvent e) {
		/**鼠标移到组件上方法时事件处理方法.**/}

		public void mouseExited(MouseEvent e) {
		/**鼠标移开组件时事件处理方法.**/}

		public void mousePressed(MouseEvent e) {
		/**鼠标在组件上按下(但没弹起)时事件处理方法.**/}

		public void mouseReleased(MouseEvent e) {
		/**鼠标在组件上弹起事件处理方法.**/}
}
