package dao;



import javax.swing.JFrame;

import pojo.*;

import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JButton;






import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;


/**
 * 购物车界面
 * @author Anjail
 *
 */
public class CartGUI {

	 static JFrame frame_cart;		//	购物车面板
	private JTextArea textArea;
	 static String ownpet;
	 static String s;			//保存购买到的物品信息
	 
	 double leftMoney ;
	/**
	 * Create the application.
	 */
	public CartGUI() {
		initialize();
		frame_cart.setVisible(false);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		/**
		 * 购物车面板
		 */
		frame_cart = new JFrame("我的购物车");
		frame_cart.setBounds(100, 100, 861, 456);
		frame_cart.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame_cart.getContentPane().setLayout(null);
		frame_cart.setResizable(false);
		
		 textArea = new JTextArea("以下是您购物车中存在的商品 : \n");
		textArea.setBounds(60, 172, 429, 195);
		frame_cart.getContentPane().add(textArea);
		
		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setBounds(47, 154, 480, 180);
		frame_cart.add(scrollPane);
		
				scrollPane.setVerticalScrollBarPolicy( 
						JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); 
		
		JLabel lblNewLabel = new JLabel("欢迎查看您的购物车");
		lblNewLabel.setFont(new Font("微软雅黑", Font.BOLD, 21));
		lblNewLabel.setBounds(94, 35, 311, 47);
		frame_cart.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("返回宠物详细界面");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame_cart.setVisible(false);
				StoreGUI.frame.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("微软雅黑", Font.BOLD, 16));
		btnNewButton.setBounds(603, 277, 175, 68);
		frame_cart.getContentPane().add(btnNewButton);
		
		
		
		
			
		
		JButton btnNewButton_1 = new JButton("结      算");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int n = JOptionPane.showConfirmDialog(null, "确定购买吗?", "确认结算框", JOptionPane.YES_NO_OPTION);
				if(n==JOptionPane.YES_OPTION){
					SQL sql = new SQL();
					
					//遍历数据库user表用于获得余额
					UserData ud = new UserData();
					ArrayList<User> userdata = new ArrayList<User>();
					userdata = ud.read();
					for(User u : userdata){
						if(u.getName().equals(LoginGUI.userName))
						{
					leftMoney = u.getMoney()-95.0*PetDetails.click_dog-125.8*PetDetails.click_cat-49.9*PetDetails.click_fish
							-88.5*PetDetails.click_turtle-155.9*PetDetails.click_parrot-58.0*PetDetails.click_hamster-120.0*PetDetails.click_squirrel
							-70.5*PetDetails.click_rabbit-100.0*PetDetails.click_snake-77.5*PetDetails.click_lizard-129.5*PetDetails.click_myna-150.0*PetDetails.click_canary;
					}
					}
					s = getOwn();
					
					StoreGUI.bought = StoreGUI.bought  + s;
			
					sql.dataUpdate(LoginGUI.userName, leftMoney, StoreGUI.bought );
					//结算之后 所有宠物个数 清零
					PetDetails.click_canary =0;
					PetDetails.click_dog =0;
					PetDetails.click_fish=0;
					PetDetails.click_cat =0;
					PetDetails.click_myna =0;
					PetDetails.click_parrot=0;
					PetDetails.click_turtle =0;
					PetDetails.click_snake =0;
					PetDetails.click_hamster =0;
					PetDetails.click_lizard =0;
					PetDetails.click_rabbit =0;
					PetDetails.click_squirrel =0;
					JOptionPane.showMessageDialog(null, "恭喜你结算成功，点击个人信息查看购买到的物品", "提示消息",JOptionPane.PLAIN_MESSAGE);
				}
				if(n==JOptionPane.NO_OPTION){
					
				}
			}
		});
		btnNewButton_1.setFont(new Font("宋体", Font.BOLD, 18));
		btnNewButton_1.setBounds(603, 170, 175, 68);
		frame_cart.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("点击查看购物车的内容");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Show();
			}
		});
		btnNewButton_2.setBounds(136, 111, 175, 32);
		frame_cart.getContentPane().add(btnNewButton_2);
		
	
	}
	
	public void Show(){
//		UserData ud = new UserData();
//		ArrayList<User> userdata = new ArrayList<User>();
//		userdata = ud.read();
		Cart c = PetDetails.cart;
		textArea.setText("以下是您购物车中存在的商品 : \n");
			for(String p : c.getPetname()){
				
				
				if(p.equals("cat" )&& PetDetails.click_cat!=0){
					
					textArea.append(""+"\ncat  * "+PetDetails.click_cat);
				
				}
				if(p.equals("dog") && PetDetails.click_dog!=0){
					textArea.append(""+"\ndog  * "+PetDetails.click_dog);
				}
				if(p.equals("myna") && PetDetails.click_myna!=0){
				textArea.append(""+"\nmyna  * "+PetDetails.click_myna);
				}
				if(p.equals("parrot") && PetDetails.click_parrot!=0){
					textArea.append(""+"\nparrot  * "+PetDetails.click_parrot);
				}
				if(p.equals("lizard") && PetDetails.click_lizard!=0){
					textArea.append(""+"\nlizard  * "+PetDetails.click_lizard);
				}
				if(p.equals("fish") && PetDetails.click_fish!=0){
					textArea.append(""+"\nfish  * "+PetDetails.click_fish);
				}
				if(p.equals("rabbit") && PetDetails.click_rabbit!=0){
					textArea.append(""+"\nrabbit  * "+PetDetails.click_rabbit);
				}
				if(p.equals("canary") && PetDetails.click_canary!=0){
					textArea.append(""+"\ncanary  * "+PetDetails.click_canary);
				}
				if(p.equals("turtle") && PetDetails.click_turtle!=0){
					textArea.append(""+"\nturtle  * "+PetDetails.click_turtle);
				}
				if(p.equals("hamster") && PetDetails.click_hamster!=0){
					textArea.append(""+"\nhamster  * "+PetDetails.click_hamster);
				}
				if(p.equals("snake") && PetDetails.click_snake!=0){
					textArea.append(""+"\nsnake  * "+PetDetails.click_snake);
				}
				if(p.equals("squirrel") && PetDetails.click_squirrel!=0){
					textArea.append(""+"\nsquirrel  * "+PetDetails.click_squirrel);
				}
				
			}
			
		ownpet = textArea.getText();
	}
	
	
	public String getOwn(){
		String s[] =ownpet.split(":");
		String s1;
		s1=s[s.length-1];
		return s1;
	}
	
}
