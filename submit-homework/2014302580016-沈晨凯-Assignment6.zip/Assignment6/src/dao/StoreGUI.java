package dao;


import service.*;
import pojo.*;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JScrollPane;

import java.awt.Font;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

import javax.swing.JTextArea;

/**
 * 该界面显示宠物商店的主界面 12个宠物
 * @author Anjail
 *
 */


public class StoreGUI {

	public static JFrame frame;
	
	
	/**
	 * label1-12为 12种动物的标签
	 */
	private static JLabel label1;
	private static JLabel label2;
	private static JLabel label3;
	private static JLabel label4;
	private static JLabel label5;
	private static JLabel label6;
	private static JLabel label7;
	private static JLabel label8;
	private static JLabel label9;
	private static JLabel label10;
	private static JLabel label11;
	private static JLabel label12;
	
	/**
	 * 12个是动物名称的标签
	 */
	private JLabel lblCat;
	private JLabel lblDog;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_4;
	private JLabel lblNewLabel_5;
	private JLabel lblNewLabel_6;
	private JLabel lblNewLabel_7;
	private JLabel lblNewLabel_8;
	private JLabel lblNewLabel_9;
	private JLabel lblNewLabel_10;
	private JButton btnNewButton;
	private JButton btnNewButton_1;
	private JTextArea textArea;
	
	
	static String bought="";
	/**
	 * Create the application.
	 */
	public StoreGUI() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("宠物商店");
		frame.setBounds(100,100, 1000, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		
		JPanel jp = new JPanel();
		jp.setBounds(20, 20, 800, 600);
		
		//cat
		ImageIcon icon1=new ImageIcon("cat.png");
		 label1=new JLabel(icon1);				
		label1.setBounds(30, 30, 128, 128);
		label1.addMouseListener(new MouseAdp());
		
		//dog
		ImageIcon icon2=new ImageIcon("dog.png");
		 label2=new JLabel(icon2);				
		label2.setBounds(220, 30, 128, 128);
		label2.addMouseListener(new MouseAdp());
		//fish
		ImageIcon icon3=new ImageIcon("fish.png");
		 label3=new JLabel(icon3);				
		label3.setBounds(420, 30, 128, 128);
		label3.addMouseListener(new MouseAdp());
		//rabbit
		ImageIcon icon4=new ImageIcon("rabbit.png");
		 label4=new JLabel(icon4);				
		label4.setBounds(620, 30, 128, 128);
		label4.addMouseListener(new MouseAdp());
		//canary
		ImageIcon icon5=new ImageIcon("canary.png");
		 label5=new JLabel(icon5);				
		label5.setBounds(30, 200, 128, 128);
		label5.addMouseListener(new MouseAdp());
		//parrot
		ImageIcon icon6=new ImageIcon("parrot.png");
		 label6=new JLabel(icon6);				
		label6.setBounds(220, 200, 128, 128);
		label6.addMouseListener(new MouseAdp());
		//lizard
		ImageIcon icon7=new ImageIcon("lizard.png");
		 label7=new JLabel(icon7);				
		label7.setBounds(420, 200, 128, 128);
		label7.addMouseListener(new MouseAdp());
		//turtle
		ImageIcon icon8=new ImageIcon("turtle.png");
		 label8=new JLabel(icon8);				
		label8.setBounds(620,200, 128, 128);
		label8.addMouseListener(new MouseAdp());
		//hamster
		ImageIcon icon9=new ImageIcon("hamster.png");
		 label9=new JLabel(icon9);				
		label9.setBounds(30, 370, 128, 128);
		label9.addMouseListener(new MouseAdp());
		//snake
		ImageIcon icon10=new ImageIcon("snake.png");
		label10=new JLabel(icon10);
		label10.setBounds(220, 370, 128, 128);
		label10.addMouseListener(new MouseAdp());
		//squirrel
		ImageIcon icon11=new ImageIcon("squirrel.png");
		 label11=new JLabel(icon11);				
		label11.setBounds(420, 370, 128, 128);
		label11.addMouseListener(new MouseAdp());
		//myna
		ImageIcon icon12=new ImageIcon("myna.png");
		 label12=new JLabel(icon12);			
		label12.setBounds(620, 370, 128, 128);
		label12.addMouseListener(new MouseAdp());
				


		jp.setLayout(null);
		jp.setVisible(true);
		frame.getContentPane().setLayout(null);
		
		jp.add(label1);
		jp.add(label2);
		jp.add(label3);
		jp.add(label4);
		jp.add(label5);
		jp.add(label6);
		jp.add(label7);
		jp.add(label8);
		jp.add(label9);
		jp.add(label10);
		jp.add(label11);
		jp.add(label12);
		
	
		
		frame.getContentPane().add(jp);
		
		lblCat = new JLabel("cat");
		lblCat.setFont(new Font("微软雅黑", Font.BOLD, 14));
		lblCat.setBounds(69, 175, 54, 15);
		jp.add(lblCat);
		
		lblDog = new JLabel("dog");
		lblDog.setFont(new Font("微软雅黑", Font.BOLD, 14));
		lblDog.setBounds(255, 175, 54, 15);
		jp.add(lblDog);
		
		lblNewLabel_1 = new JLabel("fish");
		lblNewLabel_1.setFont(new Font("微软雅黑", Font.BOLD, 14));
		lblNewLabel_1.setBounds(464, 175, 54, 15);
		jp.add(lblNewLabel_1);
		
		lblNewLabel_2 = new JLabel("rabbit");
		lblNewLabel_2.setFont(new Font("微软雅黑", Font.BOLD, 14));
		lblNewLabel_2.setBounds(669, 175, 54, 15);
		jp.add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("canary");
		lblNewLabel_3.setFont(new Font("微软雅黑", Font.BOLD, 14));
		lblNewLabel_3.setBounds(69, 338, 54, 15);
		jp.add(lblNewLabel_3);
		
		lblNewLabel_4 = new JLabel("parrot");
		lblNewLabel_4.setFont(new Font("微软雅黑", Font.BOLD, 14));
		lblNewLabel_4.setBounds(255, 338, 54, 15);
		jp.add(lblNewLabel_4);
		
		lblNewLabel_5 = new JLabel("lizard");
		lblNewLabel_5.setFont(new Font("微软雅黑", Font.BOLD, 14));
		lblNewLabel_5.setBounds(464, 338, 54, 15);
		jp.add(lblNewLabel_5);
		
		lblNewLabel_6 = new JLabel("turtle");
		lblNewLabel_6.setFont(new Font("微软雅黑", Font.BOLD, 14));
		lblNewLabel_6.setBounds(669, 338, 54, 15);
		jp.add(lblNewLabel_6);
		
		lblNewLabel_7 = new JLabel("hamster");
		lblNewLabel_7.setFont(new Font("微软雅黑", Font.BOLD, 14));
		lblNewLabel_7.setBounds(69, 518, 73, 15);
		jp.add(lblNewLabel_7);
		
		lblNewLabel_8 = new JLabel("snake");
		lblNewLabel_8.setFont(new Font("微软雅黑", Font.BOLD, 14));
		lblNewLabel_8.setBounds(255, 518, 54, 15);
		jp.add(lblNewLabel_8);
		
		lblNewLabel_9 = new JLabel("squirrel");
		lblNewLabel_9.setFont(new Font("微软雅黑", Font.BOLD, 14));
		lblNewLabel_9.setBounds(464, 518, 54, 15);
		jp.add(lblNewLabel_9);
		
		lblNewLabel_10 = new JLabel("myna");
		lblNewLabel_10.setFont(new Font("微软雅黑", Font.BOLD, 14));
		lblNewLabel_10.setBounds(669, 518, 54, 15);
		jp.add(lblNewLabel_10);
		
		JLabel lblNewLabel = new JLabel("请点击宠物图片查看详细信息");
		lblNewLabel.setBounds(297, 5, 261, 15);
		jp.add(lblNewLabel);
		lblNewLabel.setFont(new Font("微软雅黑", Font.PLAIN, 14));
		
		btnNewButton = new JButton("退       出");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				LoginGUI.frame.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("微软雅黑 Light", Font.BOLD, 14));
		btnNewButton.setBounds(830, 121, 137, 44);
		frame.getContentPane().add(btnNewButton);
		
		
		btnNewButton_1 = new JButton("查看个人信息");    
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserData ud = new UserData();
				ArrayList<User> userdata = new ArrayList<User>();
				userdata = ud.read();
				for(User u : userdata){
					if(u.getName().equals(LoginGUI.userName))
				textArea.append("你好!  " + LoginGUI.getuserName() +"\n 您的余额为: " +u.getMoney() + "元。\n您购买的宠物有：\n"+u.getGoods()+"\n");
				}
			}
		});
		btnNewButton_1.setFont(new Font("微软雅黑", Font.BOLD, 14));
		btnNewButton_1.setBounds(830, 47, 137, 53);
		frame.getContentPane().add(btnNewButton_1);
		
		textArea = new JTextArea();
		textArea.setText("");
		textArea.setBounds(820, 195, 164, 208);
		frame.getContentPane().add(textArea);
		
		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setBounds(820, 195, 164, 208);
		frame.add(scrollPane);
		
				scrollPane.setVerticalScrollBarPolicy( 
						JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); 
	

	}
	public static JLabel getLabel1(){
		return label1;
	}
	public static JLabel getLabel2(){
		return label2;
	}
	public static JLabel getLabel3(){
		return label3;
	}
	public static JLabel getLabel4(){
		return label4;
	}
	public static JLabel getLabel5(){
		return label5;
	}
	public static JLabel getLabel6(){
		return label6;
	}
	public static JLabel getLabel7(){
		return label7;
	}
	public static JLabel getLabel8(){
		return label8;
	}
	public static JLabel getLabel9(){
		return label9;
	}
	public static JLabel getLabel10(){
		return label10;
	}
	public static JLabel getLabel11(){
		return label11;
	}
	public static JLabel getLabel12(){
		return label12;
	}
	
	
}





