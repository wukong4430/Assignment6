package dao;



import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JButton;

import pojo.*;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.awt.Font;

/**
 * 该界面用于显示各种宠物的详细信息
 * @author Anjail
 *
 */
public class PetDetails {
	
	
	private JFrame frame_cat;
	private JFrame frame_dog;
	private JFrame frame_fish;
	private JFrame frame_rabbit;
	private JFrame frame_myna;
	private JFrame frame_parrot;
	private JFrame frame_lizard;
	private JFrame frame_snake;
	private JFrame frame_canary;
	private JFrame frame_turtle;
	private JFrame frame_hamster;
	private JFrame frame_squirrel;
	
	
	
	static Cart cart;
	ArrayList<String> cart_name = new ArrayList<String>();
	ArrayList<Integer> cart_number = new ArrayList<Integer>();
	
	
	static int click_cat=0;
	static int click_dog=0;
	static int click_fish=0;
	static int click_rabbit=0;
	static int click_myna=0;
	static int click_snake=0;
	static int click_parrot=0;
	static int click_turtle=0;
	static int click_hamster=0;
	static int click_squirrel=0;
	static int click_canary=0;
	static int click_lizard=0;
	

	/**
	 * Create the application.
	 */
	public PetDetails(String type) {
		initialize();
		if(type.equals("cat")){
			frame_cat.setVisible(true);
		}
		if(type.equals("dog")){
			frame_dog.setVisible(true);
		}
		if(type.equals("fish")){
			frame_fish.setVisible(true);
		}
		if(type.equals("hamster")){
			frame_hamster.setVisible(true);
		}
		if(type.equals("rabbit")){
			frame_rabbit.setVisible(true);
		}
		if(type.equals("snake")){
			frame_snake.setVisible(true);
		}
		if(type.equals("myna")){
			frame_myna.setVisible(true);
		}
		if(type.equals("parrot")){
			frame_parrot.setVisible(true);
		}
		if(type.equals("turtle")){
			frame_turtle.setVisible(true);
		}
		if(type.equals("canary")){
			frame_canary.setVisible(true);
		}
		if(type.equals("squirrel")){
			frame_squirrel.setVisible(true);
		}
		if(type.equals("lizard")){
			frame_lizard.setVisible(true);
		}
		cart = new Cart(cart_name, cart_number);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		

		
		catframe();//cat
		dogframe();
		fishframe();
		rabbitframe();
		parrotframe();
		mynaframe();
		snakeframe();
		squirrelframe();
		canaryframe();
		turtleframe();
		hamsterframe();
		lizardframe();

}


//catframe
public void catframe(){
	
	/**
	 * 创建宠物类顺序表，获取数据库中的宠物信息
	 */
	PetSql ps = new PetSql();
	ArrayList<Pet> data = new ArrayList<Pet>();
	data = ps.read();
	
	
	//cat frame
			frame_cat = new JFrame("宠物的详细信息");
			frame_cat.setBounds(100, 100, 861, 456);
			frame_cat.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame_cat.getContentPane().setLayout(null);
			
			ImageIcon icon1=new ImageIcon("cat.png");
			 JLabel label1=new JLabel(icon1);				
			label1.setBounds(180, 10, 128, 128);
			frame_cat.getContentPane().add(label1);
		
			JTextArea textArea_cat = new JTextArea();
			for(Pet p : data){
				if(p.getName().equals("cat")){
					textArea_cat.setText("This is a lovely animal!\n Its name : " +p.getName() +"	\neat : " + p.getEat() +
							"\ndrink : " + p.getDrink() +"\nlive : " + p.getLive() +"\nhobby : " + p.getHobby() +"\nprice : " + p.getPrice()+"\n");
				}
			}
			
			textArea_cat.setBounds(109, 155, 543, 150);
			frame_cat.getContentPane().add(textArea_cat);
			
			JButton btnNewButton1 = new JButton("返回宠物列表");
			btnNewButton1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					StoreGUI.frame.setVisible(true);
					frame_cat.setVisible(false);
				}
			});
			btnNewButton1.setBackground(Color.LIGHT_GRAY);
			btnNewButton1.setForeground(Color.BLACK);
			btnNewButton1.setBounds(95, 333, 127, 37);
			frame_cat.getContentPane().add(btnNewButton1);
			
			JButton btnNewButton = new JButton("加入购物车");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					JOptionPane.showMessageDialog(null,"加入购物车成功！");
					click_cat++;
					
					
					
				}
			});
					cart_name.add("cat");
					cart_number.add(click_cat);
			btnNewButton.setFont(new Font("微软雅黑", Font.BOLD, 14));
			btnNewButton.setBounds(332, 333, 155, 37);
			frame_cat.getContentPane().add(btnNewButton);
			
			JButton btnNewButton_1 = new JButton("我的购物车");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame_cat.setVisible(false);
					CartGUI.frame_cart.setVisible(true);
				}
			});
			btnNewButton_1.setFont(new Font("幼圆", Font.BOLD, 14));
			btnNewButton_1.setBounds(573, 336, 121, 34);
			frame_cat.getContentPane().add(btnNewButton_1);
			
			JLabel lblNewLabel = new JLabel("(单位：元)");
			lblNewLabel.setBounds(701, 182, 68, 37);
			frame_cat.getContentPane().add(lblNewLabel);
			
}

public void dogframe(){

	
	/**
	 * 创建宠物类顺序表，获取数据库中的宠物信息
	 */
	PetSql ps = new PetSql();
	ArrayList<Pet> data = new ArrayList<Pet>();
	data = ps.read();
	
	//dog frame
	frame_dog = new JFrame("宠物的详细信息");
	frame_dog.setBounds(100, 100, 861, 456);
	frame_dog.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame_dog.getContentPane().setLayout(null);
	
	ImageIcon icon2=new ImageIcon("dog.png");
	 JLabel label2=new JLabel(icon2);				
	label2.setBounds(180, 10, 128, 128);
	frame_dog.getContentPane().add(label2);

	JTextArea textArea_dog = new JTextArea();
	for(Pet p : data){
		if(p.getName().equals("dog")){
			textArea_dog.append("This is a lovely animal!\n Its name : " +p.getName() +"	\neat : " + p.getEat() +
					"\ndrink : " + p.getDrink() +"\nlive : " + p.getLive() +"\nhobby : " + p.getHobby() +"\nprice : " + p.getPrice()+"\n");
		}
	}
	
	textArea_dog.setBounds(109, 155, 543, 150);
	frame_dog.getContentPane().add(textArea_dog);
	
	JButton btnNewButton2 = new JButton("返回宠物列表");
	btnNewButton2.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			StoreGUI.frame.setVisible(true);
			frame_dog.setVisible(false);
		}
	});
	btnNewButton2.setBackground(Color.LIGHT_GRAY);
	btnNewButton2.setForeground(Color.BLACK);
	btnNewButton2.setBounds(95, 333, 127, 37);
	frame_dog.getContentPane().add(btnNewButton2);
	
	JButton btnNewButton22 = new JButton("加入购物车");
	btnNewButton22.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			//SQL sql = new SQL();
			//sql.dataUpdate(LoginGUI.userName, 1000, "dog");
			JOptionPane.showMessageDialog(null,"加入购物车成功！");
			click_dog++;
			
			
		}
	});
			cart_name.add("dog");
			cart_number.add(click_dog);
	btnNewButton22.setFont(new Font("微软雅黑", Font.BOLD, 14));
	btnNewButton22.setBounds(332, 333, 155, 37);
	frame_dog.getContentPane().add(btnNewButton22);
	
	JButton btnNewButton_2 = new JButton("我的购物车");
	btnNewButton_2.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			frame_dog.setVisible(false);
			CartGUI.frame_cart.setVisible(true);
		}
	});
	btnNewButton_2.setFont(new Font("幼圆", Font.BOLD, 14));
	btnNewButton_2.setBounds(573, 336, 121, 34);
	frame_dog.getContentPane().add(btnNewButton_2);
	
	JLabel lblNewLabel2 = new JLabel("(单位：元)");
	lblNewLabel2.setBounds(701, 182, 68, 37);
	frame_dog.getContentPane().add(lblNewLabel2);
}


public void fishframe(){
	
	/**
	 * 创建宠物类顺序表，获取数据库中的宠物信息
	 */
	PetSql ps = new PetSql();
	ArrayList<Pet> data = new ArrayList<Pet>();
	data = ps.read();
	
	//fish frame
		frame_fish = new JFrame("宠物的详细信息");
		frame_fish.setBounds(100, 100, 861, 456);
		frame_fish.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame_fish.getContentPane().setLayout(null);
		
		ImageIcon icon2=new ImageIcon("fish.png");
		 JLabel label2=new JLabel(icon2);				
		label2.setBounds(180, 10, 128, 128);
		frame_fish.getContentPane().add(label2);

		JTextArea textArea_fish = new JTextArea();
		for(Pet p : data){
			if(p.getName().equals("fish")){
				textArea_fish.append("This is a lovely animal!\n Its name : " +p.getName() +"	\neat : " + p.getEat() +
						"\ndrink : " + p.getDrink() +"\nlive : " + p.getLive() +"\nhobby : " + p.getHobby() +"\nprice : " + p.getPrice()+"\n");
			}
		}
		
		textArea_fish.setBounds(109, 155, 543, 150);
		frame_fish.getContentPane().add(textArea_fish);
		
		JButton btnNewButton2 = new JButton("返回宠物列表");
		btnNewButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StoreGUI.frame.setVisible(true);
				frame_fish.setVisible(false);
			}
		});
		btnNewButton2.setBackground(Color.LIGHT_GRAY);
		btnNewButton2.setForeground(Color.BLACK);
		btnNewButton2.setBounds(95, 333, 127, 37);
		frame_fish.getContentPane().add(btnNewButton2);
		
		JButton btnNewButton22 = new JButton("加入购物车");
		btnNewButton22.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				JOptionPane.showMessageDialog(null,"加入购物车成功！");
				click_fish++;
				
				
			}
		});
				cart_name.add("fish");
				cart_number.add(click_fish);
		btnNewButton22.setFont(new Font("微软雅黑", Font.BOLD, 14));
		btnNewButton22.setBounds(332, 333, 155, 37);
		frame_fish.getContentPane().add(btnNewButton22);
		
		JButton btnNewButton_2 = new JButton("我的购物车");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame_fish.setVisible(false);
				CartGUI.frame_cart.setVisible(true);
			}
		});
		btnNewButton_2.setFont(new Font("幼圆", Font.BOLD, 14));
		btnNewButton_2.setBounds(573, 336, 121, 34);
		frame_fish.getContentPane().add(btnNewButton_2);
		
		JLabel lblNewLabel2 = new JLabel("(单位：元)");
		lblNewLabel2.setBounds(701, 182, 68, 37);
		frame_fish.getContentPane().add(lblNewLabel2);
}


public void rabbitframe(){
	/**
	 * 创建宠物类顺序表，获取数据库中的宠物信息
	 */
	PetSql ps = new PetSql();
	ArrayList<Pet> data = new ArrayList<Pet>();
	data = ps.read();
	
	
	//rabbit frame
			frame_rabbit = new JFrame("宠物的详细信息");
			frame_rabbit.setBounds(100, 100, 861, 456);
			frame_rabbit.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame_rabbit.getContentPane().setLayout(null);
			
			ImageIcon icon1=new ImageIcon("rabbit.png");
			 JLabel label1=new JLabel(icon1);				
			label1.setBounds(180, 10, 128, 128);
			frame_rabbit.getContentPane().add(label1);
		
			JTextArea textArea_rabbit = new JTextArea();
			for(Pet p : data){
				if(p.getName().equals("rabbit")){
					textArea_rabbit.setText("This is a lovely animal!\n Its name : " +p.getName() +"	\neat : " + p.getEat() +
							"\ndrink : " + p.getDrink() +"\nlive : " + p.getLive() +"\nhobby : " + p.getHobby() +"\nprice : " + p.getPrice()+"\n");
				}
			}
			
			textArea_rabbit.setBounds(109, 155, 543, 150);
			frame_rabbit.getContentPane().add(textArea_rabbit);
			
			JButton btnNewButton1 = new JButton("返回宠物列表");
			btnNewButton1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					StoreGUI.frame.setVisible(true);
					frame_rabbit.setVisible(false);
				}
			});
			btnNewButton1.setBackground(Color.LIGHT_GRAY);
			btnNewButton1.setForeground(Color.BLACK);
			btnNewButton1.setBounds(95, 333, 127, 37);
			frame_rabbit.getContentPane().add(btnNewButton1);
			
			JButton btnNewButton = new JButton("加入购物车");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					JOptionPane.showMessageDialog(null,"加入购物车成功！");
					click_rabbit++;
					
					
					
				}
			});
					cart_name.add("rabbit");
					cart_number.add(click_rabbit);
			btnNewButton.setFont(new Font("微软雅黑", Font.BOLD, 14));
			btnNewButton.setBounds(332, 333, 155, 37);
			frame_rabbit.getContentPane().add(btnNewButton);
			
			JButton btnNewButton_1 = new JButton("我的购物车");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame_rabbit.setVisible(false);
					CartGUI.frame_cart.setVisible(true);
				}
			});
			btnNewButton_1.setFont(new Font("幼圆", Font.BOLD, 14));
			btnNewButton_1.setBounds(573, 336, 121, 34);
			frame_rabbit.getContentPane().add(btnNewButton_1);
			
			JLabel lblNewLabel = new JLabel("(单位：元)");
			lblNewLabel.setBounds(701, 182, 68, 37);
			frame_rabbit.getContentPane().add(lblNewLabel);
}


public void parrotframe(){
	/**
	 * 创建宠物类顺序表，获取数据库中的宠物信息
	 * 
	 */
	PetSql ps = new PetSql();
	ArrayList<Pet> data = new ArrayList<Pet>();
	data = ps.read();
	
	
	//parrot frame
			frame_parrot = new JFrame("宠物的详细信息");
			frame_parrot.setBounds(100, 100, 861, 456);
			frame_parrot.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame_parrot.getContentPane().setLayout(null);
			
			ImageIcon icon1=new ImageIcon("parrot.png");
			 JLabel label1=new JLabel(icon1);				
			label1.setBounds(180, 10, 128, 128);
			frame_parrot.getContentPane().add(label1);
		
			JTextArea textArea_parrot = new JTextArea();
			for(Pet p : data){
				if(p.getName().equals("parrot")){
					textArea_parrot.setText("This is a lovely animal!\n Its name : " +p.getName() +"	\neat : " + p.getEat() +
							"\ndrink : " + p.getDrink() +"\nlive : " + p.getLive() +"\nhobby : " + p.getHobby() +"\nprice : " + p.getPrice()+"\n");
				}
			}
			
			textArea_parrot.setBounds(109, 155, 543, 150);
			frame_parrot.getContentPane().add(textArea_parrot);
			
			JButton btnNewButton1 = new JButton("返回宠物列表");
			btnNewButton1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					StoreGUI.frame.setVisible(true);
					frame_parrot.setVisible(false);
				}
			});
			btnNewButton1.setBackground(Color.LIGHT_GRAY);
			btnNewButton1.setForeground(Color.BLACK);
			btnNewButton1.setBounds(95, 333, 127, 37);
			frame_parrot.getContentPane().add(btnNewButton1);
			
			JButton btnNewButton = new JButton("加入购物车");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					JOptionPane.showMessageDialog(null,"加入购物车成功！");
					click_parrot++;
					
					
					
				}
			});
					cart_name.add("parrot");
					cart_number.add(click_parrot);
			btnNewButton.setFont(new Font("微软雅黑", Font.BOLD, 14));
			btnNewButton.setBounds(332, 333, 155, 37);
			frame_parrot.getContentPane().add(btnNewButton);
			
			JButton btnNewButton_1 = new JButton("我的购物车");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame_parrot.setVisible(false);
					CartGUI.frame_cart.setVisible(true);
				}
			});
			btnNewButton_1.setFont(new Font("幼圆", Font.BOLD, 14));
			btnNewButton_1.setBounds(573, 336, 121, 34);
			frame_parrot.getContentPane().add(btnNewButton_1);
			
			JLabel lblNewLabel = new JLabel("(单位：元)");
			lblNewLabel.setBounds(701, 182, 68, 37);
			frame_parrot.getContentPane().add(lblNewLabel);
}



public void lizardframe(){
	/**
	 * 创建宠物类顺序表，获取数据库中的宠物信息
	 * 
	 */
	PetSql ps = new PetSql();
	ArrayList<Pet> data = new ArrayList<Pet>();
	data = ps.read();
	
	
	//lizard frame
			frame_lizard = new JFrame("宠物的详细信息");
			frame_lizard.setBounds(100, 100, 861, 456);
			frame_lizard.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame_lizard.getContentPane().setLayout(null);
			
			ImageIcon icon1=new ImageIcon("lizard.png");
			 JLabel label1=new JLabel(icon1);				
			label1.setBounds(180, 10, 128, 128);
			frame_lizard.getContentPane().add(label1);
		
			JTextArea textArea_lizard = new JTextArea();
			for(Pet p : data){
				if(p.getName().equals("lizard")){
					textArea_lizard.setText("This is a lovely animal!\n Its name : " +p.getName() +"	\neat : " + p.getEat() +
							"\ndrink : " + p.getDrink() +"\nlive : " + p.getLive() +"\nhobby : " + p.getHobby() +"\nprice : " + p.getPrice()+"\n");
				}
			}
			
			textArea_lizard.setBounds(109, 155, 543, 150);
			frame_lizard.getContentPane().add(textArea_lizard);
			
			JButton btnNewButton1 = new JButton("返回宠物列表");
			btnNewButton1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					StoreGUI.frame.setVisible(true);
					frame_lizard.setVisible(false);
				}
			});
			btnNewButton1.setBackground(Color.LIGHT_GRAY);
			btnNewButton1.setForeground(Color.BLACK);
			btnNewButton1.setBounds(95, 333, 127, 37);
			frame_lizard.getContentPane().add(btnNewButton1);
			
			JButton btnNewButton = new JButton("加入购物车");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					JOptionPane.showMessageDialog(null,"加入购物车成功！");
					click_lizard++;
					
					
					
				}
			});
					cart_name.add("lizard");
					cart_number.add(click_lizard);
			btnNewButton.setFont(new Font("微软雅黑", Font.BOLD, 14));
			btnNewButton.setBounds(332, 333, 155, 37);
			frame_lizard.getContentPane().add(btnNewButton);
			
			JButton btnNewButton_1 = new JButton("我的购物车");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame_lizard.setVisible(false);
					CartGUI.frame_cart.setVisible(true);
				}
			});
			btnNewButton_1.setFont(new Font("幼圆", Font.BOLD, 14));
			btnNewButton_1.setBounds(573, 336, 121, 34);
			frame_lizard.getContentPane().add(btnNewButton_1);
			
			JLabel lblNewLabel = new JLabel("(单位：元)");
			lblNewLabel.setBounds(701, 182, 68, 37);
			frame_lizard.getContentPane().add(lblNewLabel);
}



public void snakeframe(){
	/**
	 * 创建宠物类顺序表，获取数据库中的宠物信息
	 * 
	 */
	PetSql ps = new PetSql();
	ArrayList<Pet> data = new ArrayList<Pet>();
	data = ps.read();
	
	
	//snake frame
			frame_snake = new JFrame("宠物的详细信息");
			frame_snake.setBounds(100, 100, 861, 456);
			frame_snake.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame_snake.getContentPane().setLayout(null);
			
			ImageIcon icon1=new ImageIcon("snake.png");
			 JLabel label1=new JLabel(icon1);				
			label1.setBounds(180, 10, 128, 128);
			frame_snake.getContentPane().add(label1);
		
			JTextArea textArea_snake = new JTextArea();
			for(Pet p : data){
				if(p.getName().equals("snake")){
					textArea_snake.setText("This is a lovely animal!\n Its name : " +p.getName() +"	\neat : " + p.getEat() +
							"\ndrink : " + p.getDrink() +"\nlive : " + p.getLive() +"\nhobby : " + p.getHobby() +"\nprice : " + p.getPrice()+"\n");
				}
			}
			
			textArea_snake.setBounds(109, 155, 543, 150);
			frame_snake.getContentPane().add(textArea_snake);
			
			JButton btnNewButton1 = new JButton("返回宠物列表");
			btnNewButton1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					StoreGUI.frame.setVisible(true);
					frame_snake.setVisible(false);
				}
			});
			btnNewButton1.setBackground(Color.LIGHT_GRAY);
			btnNewButton1.setForeground(Color.BLACK);
			btnNewButton1.setBounds(95, 333, 127, 37);
			frame_snake.getContentPane().add(btnNewButton1);
			
			JButton btnNewButton = new JButton("加入购物车");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					JOptionPane.showMessageDialog(null,"加入购物车成功！");
					click_snake++;
					
					
					
				}
			});
					cart_name.add("snake");
					cart_number.add(click_snake);
			btnNewButton.setFont(new Font("微软雅黑", Font.BOLD, 14));
			btnNewButton.setBounds(332, 333, 155, 37);
			frame_snake.getContentPane().add(btnNewButton);
			
			JButton btnNewButton_1 = new JButton("我的购物车");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame_snake.setVisible(false);
					CartGUI.frame_cart.setVisible(true);
				}
			});
			btnNewButton_1.setFont(new Font("幼圆", Font.BOLD, 14));
			btnNewButton_1.setBounds(573, 336, 121, 34);
			frame_snake.getContentPane().add(btnNewButton_1);
			
			JLabel lblNewLabel = new JLabel("(单位：元)");
			lblNewLabel.setBounds(701, 182, 68, 37);
			frame_snake.getContentPane().add(lblNewLabel);
}



public void canaryframe(){
	/**
	 * 创建宠物类顺序表，获取数据库中的宠物信息
	 * 
	 */
	PetSql ps = new PetSql();
	ArrayList<Pet> data = new ArrayList<Pet>();
	data = ps.read();
	
	
	//canary frame
			frame_canary = new JFrame("宠物的详细信息");
			frame_canary.setBounds(100, 100, 861, 456);
			frame_canary.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame_canary.getContentPane().setLayout(null);
			
			ImageIcon icon1=new ImageIcon("canary.png");
			 JLabel label1=new JLabel(icon1);				
			label1.setBounds(180, 10, 128, 128);
			frame_canary.getContentPane().add(label1);
		
			JTextArea textArea_canary = new JTextArea();
			for(Pet p : data){
				if(p.getName().equals("canary")){
					textArea_canary.setText("This is a lovely animal!\n Its name : " +p.getName() +"	\neat : " + p.getEat() +
							"\ndrink : " + p.getDrink() +"\nlive : " + p.getLive() +"\nhobby : " + p.getHobby() +"\nprice : " + p.getPrice()+"\n");
				}
			}
			
			textArea_canary.setBounds(109, 155, 543, 150);
			frame_canary.getContentPane().add(textArea_canary);
			
			JButton btnNewButton1 = new JButton("返回宠物列表");
			btnNewButton1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					StoreGUI.frame.setVisible(true);
					frame_canary.setVisible(false);
				}
			});
			btnNewButton1.setBackground(Color.LIGHT_GRAY);
			btnNewButton1.setForeground(Color.BLACK);
			btnNewButton1.setBounds(95, 333, 127, 37);
			frame_canary.getContentPane().add(btnNewButton1);
			
			JButton btnNewButton = new JButton("加入购物车");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					JOptionPane.showMessageDialog(null,"加入购物车成功！");
					click_canary++;
					
					
					
				}
			});
					cart_name.add("canary");
					cart_number.add(click_canary);
			btnNewButton.setFont(new Font("微软雅黑", Font.BOLD, 14));
			btnNewButton.setBounds(332, 333, 155, 37);
			frame_canary.getContentPane().add(btnNewButton);
			
			JButton btnNewButton_1 = new JButton("我的购物车");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame_canary.setVisible(false);
					CartGUI.frame_cart.setVisible(true);
				}
			});
			btnNewButton_1.setFont(new Font("幼圆", Font.BOLD, 14));
			btnNewButton_1.setBounds(573, 336, 121, 34);
			frame_canary.getContentPane().add(btnNewButton_1);
			
			JLabel lblNewLabel = new JLabel("(单位：元)");
			lblNewLabel.setBounds(701, 182, 68, 37);
			frame_canary.getContentPane().add(lblNewLabel);
}



public void squirrelframe(){
	/**
	 * 创建宠物类顺序表，获取数据库中的宠物信息
	 * 
	 */
	PetSql ps = new PetSql();
	ArrayList<Pet> data = new ArrayList<Pet>();
	data = ps.read();
	
	
	//squirrel frame
			frame_squirrel = new JFrame("宠物的详细信息");
			frame_squirrel.setBounds(100, 100, 861, 456);
			frame_squirrel.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame_squirrel.getContentPane().setLayout(null);
			
			ImageIcon icon1=new ImageIcon("squirrel.png");
			 JLabel label1=new JLabel(icon1);				
			label1.setBounds(180, 10, 128, 128);
			frame_squirrel.getContentPane().add(label1);
		
			JTextArea textArea_squirrel = new JTextArea();
			for(Pet p : data){
				if(p.getName().equals("squirrel")){
					textArea_squirrel.setText("This is a lovely animal!\n Its name : " +p.getName() +"	\neat : " + p.getEat() +
							"\ndrink : " + p.getDrink() +"\nlive : " + p.getLive() +"\nhobby : " + p.getHobby() +"\nprice : " + p.getPrice()+"\n");
				}
			}
			
			textArea_squirrel.setBounds(109, 155, 543, 150);
			frame_squirrel.getContentPane().add(textArea_squirrel);
			
			JButton btnNewButton1 = new JButton("返回宠物列表");
			btnNewButton1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					StoreGUI.frame.setVisible(true);
					frame_squirrel.setVisible(false);
				}
			});
			btnNewButton1.setBackground(Color.LIGHT_GRAY);
			btnNewButton1.setForeground(Color.BLACK);
			btnNewButton1.setBounds(95, 333, 127, 37);
			frame_squirrel.getContentPane().add(btnNewButton1);
			
			JButton btnNewButton = new JButton("加入购物车");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					JOptionPane.showMessageDialog(null,"加入购物车成功！");
					click_squirrel++;
					
					
					
				}
			});
					cart_name.add("squirrel");
					cart_number.add(click_squirrel);
			btnNewButton.setFont(new Font("微软雅黑", Font.BOLD, 14));
			btnNewButton.setBounds(332, 333, 155, 37);
			frame_squirrel.getContentPane().add(btnNewButton);
			
			JButton btnNewButton_1 = new JButton("我的购物车");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame_squirrel.setVisible(false);
					CartGUI.frame_cart.setVisible(true);
				}
			});
			btnNewButton_1.setFont(new Font("幼圆", Font.BOLD, 14));
			btnNewButton_1.setBounds(573, 336, 121, 34);
			frame_squirrel.getContentPane().add(btnNewButton_1);
			
			JLabel lblNewLabel = new JLabel("(单位：元)");
			lblNewLabel.setBounds(701, 182, 68, 37);
			frame_squirrel.getContentPane().add(lblNewLabel);
}



public void mynaframe(){
	/**
	 * 创建宠物类顺序表，获取数据库中的宠物信息
	 */
	PetSql ps = new PetSql();
	ArrayList<Pet> data = new ArrayList<Pet>();
	data = ps.read();
	
	
	//myna frame
			frame_myna = new JFrame("宠物的详细信息");
			frame_myna.setBounds(100, 100, 861, 456);
			frame_myna.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame_myna.getContentPane().setLayout(null);
			
			ImageIcon icon1=new ImageIcon("myna.png");
			 JLabel label1=new JLabel(icon1);				
			label1.setBounds(180, 10, 128, 128);
			frame_myna.getContentPane().add(label1);
		
			JTextArea textArea_myna = new JTextArea();
			for(Pet p : data){
				if(p.getName().equals("myna")){
					textArea_myna.setText("This is a lovely animal!\n Its name : " +p.getName() +"	\neat : " + p.getEat() +
							"\ndrink : " + p.getDrink() +"\nlive : " + p.getLive() +"\nhobby : " + p.getHobby() +"\nprice : " + p.getPrice()+"\n");
				}
			}
			
			textArea_myna.setBounds(109, 155, 543, 150);
			frame_myna.getContentPane().add(textArea_myna);
			
			JButton btnNewButton1 = new JButton("返回宠物列表");
			btnNewButton1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					StoreGUI.frame.setVisible(true);
					frame_myna.setVisible(false);
				}
			});
			btnNewButton1.setBackground(Color.LIGHT_GRAY);
			btnNewButton1.setForeground(Color.BLACK);
			btnNewButton1.setBounds(95, 333, 127, 37);
			frame_myna.getContentPane().add(btnNewButton1);
			
			JButton btnNewButton = new JButton("加入购物车");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					JOptionPane.showMessageDialog(null,"加入购物车成功！");
					click_myna++;
					
					
					
				}
			});
					cart_name.add("myna");
					cart_number.add(click_myna);
			btnNewButton.setFont(new Font("微软雅黑", Font.BOLD, 14));
			btnNewButton.setBounds(332, 333, 155, 37);
			frame_myna.getContentPane().add(btnNewButton);
			
			JButton btnNewButton_1 = new JButton("我的购物车");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame_myna.setVisible(false);
					CartGUI.frame_cart.setVisible(true);
				}
			});
			btnNewButton_1.setFont(new Font("幼圆", Font.BOLD, 14));
			btnNewButton_1.setBounds(573, 336, 121, 34);
			frame_myna.getContentPane().add(btnNewButton_1);
			
			JLabel lblNewLabel = new JLabel("(单位：元)");
			lblNewLabel.setBounds(701, 182, 68, 37);
			frame_myna.getContentPane().add(lblNewLabel);
}



public void hamsterframe(){
	/**
	 * 创建宠物类顺序表，获取数据库中的宠物信息
	 */
	PetSql ps = new PetSql();
	ArrayList<Pet> data = new ArrayList<Pet>();
	data = ps.read();
	
	
	//hamster frame
			frame_hamster = new JFrame("宠物的详细信息");
			frame_hamster.setBounds(100, 100, 861, 456);
			frame_hamster.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame_hamster.getContentPane().setLayout(null);
			
			ImageIcon icon1=new ImageIcon("hamster.png");
			 JLabel label1=new JLabel(icon1);				
			label1.setBounds(180, 10, 128, 128);
			frame_hamster.getContentPane().add(label1);
		
			JTextArea textArea_hamster = new JTextArea();
			for(Pet p : data){
				if(p.getName().equals("hamster")){
					textArea_hamster.setText("This is a lovely animal!\n Its name : " +p.getName() +"	\neat : " + p.getEat() +
							"\ndrink : " + p.getDrink() +"\nlive : " + p.getLive() +"\nhobby : " + p.getHobby() +"\nprice : " + p.getPrice()+"\n");
				}
			}
			
			textArea_hamster.setBounds(109, 155, 543, 150);
			frame_hamster.getContentPane().add(textArea_hamster);
			
			JButton btnNewButton1 = new JButton("返回宠物列表");
			btnNewButton1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					StoreGUI.frame.setVisible(true);
					frame_hamster.setVisible(false);
				}
			});
			btnNewButton1.setBackground(Color.LIGHT_GRAY);
			btnNewButton1.setForeground(Color.BLACK);
			btnNewButton1.setBounds(95, 333, 127, 37);
			frame_hamster.getContentPane().add(btnNewButton1);
			
			JButton btnNewButton = new JButton("加入购物车");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					JOptionPane.showMessageDialog(null,"加入购物车成功！");
					click_hamster++;
					
					
					
				}
			});
					cart_name.add("hamster");
					cart_number.add(click_hamster);
			btnNewButton.setFont(new Font("微软雅黑", Font.BOLD, 14));
			btnNewButton.setBounds(332, 333, 155, 37);
			frame_hamster.getContentPane().add(btnNewButton);
			
			JButton btnNewButton_1 = new JButton("我的购物车");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame_hamster.setVisible(false);
					CartGUI.frame_cart.setVisible(true);
				}
			});
			btnNewButton_1.setFont(new Font("幼圆", Font.BOLD, 14));
			btnNewButton_1.setBounds(573, 336, 121, 34);
			frame_hamster.getContentPane().add(btnNewButton_1);
			
			JLabel lblNewLabel = new JLabel("(单位：元)");
			lblNewLabel.setBounds(701, 182, 68, 37);
			frame_hamster.getContentPane().add(lblNewLabel);
}



public void turtleframe(){
	/**
	 * 创建宠物类顺序表，获取数据库中的宠物信息
	 * 
	 */
	PetSql ps = new PetSql();
	ArrayList<Pet> data = new ArrayList<Pet>();
	data = ps.read();
	
	
	//turtle frame
			frame_turtle = new JFrame("宠物的详细信息");
			frame_turtle.setBounds(100, 100, 861, 456);
			frame_turtle.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame_turtle.getContentPane().setLayout(null);
			
			ImageIcon icon1=new ImageIcon("turtle.png");
			 JLabel label1=new JLabel(icon1);				
			label1.setBounds(180, 10, 128, 128);
			frame_turtle.getContentPane().add(label1);
		
			JTextArea textArea_turtle = new JTextArea();
			for(Pet p : data){
				if(p.getName().equals("turtle")){
					textArea_turtle.setText("This is a lovely animal!\n Its name : " +p.getName() +"	\neat : " + p.getEat() +
							"\ndrink : " + p.getDrink() +"\nlive : " + p.getLive() +"\nhobby : " + p.getHobby() +"\nprice : " + p.getPrice()+"\n");
				}
			}
			
			textArea_turtle.setBounds(109, 155, 543, 150);
			frame_turtle.getContentPane().add(textArea_turtle);
			
			JButton btnNewButton1 = new JButton("返回宠物列表");
			btnNewButton1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					StoreGUI.frame.setVisible(true);
					frame_turtle.setVisible(false);
				}
			});
			btnNewButton1.setBackground(Color.LIGHT_GRAY);
			btnNewButton1.setForeground(Color.BLACK);
			btnNewButton1.setBounds(95, 333, 127, 37);
			frame_turtle.getContentPane().add(btnNewButton1);
			
			JButton btnNewButton = new JButton("加入购物车");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					JOptionPane.showMessageDialog(null,"加入购物车成功！");
					click_turtle++;
					
					
					
				}
			});
					cart_name.add("turtle");
					cart_number.add(click_turtle);
			btnNewButton.setFont(new Font("微软雅黑", Font.BOLD, 14));
			btnNewButton.setBounds(332, 333, 155, 37);
			frame_turtle.getContentPane().add(btnNewButton);
			
			JButton btnNewButton_1 = new JButton("我的购物车");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					frame_turtle.setVisible(false);
					CartGUI.frame_cart.setVisible(true);
				}
			});
			btnNewButton_1.setFont(new Font("幼圆", Font.BOLD, 14));
			btnNewButton_1.setBounds(573, 336, 121, 34);
			frame_turtle.getContentPane().add(btnNewButton_1);
			
			JLabel lblNewLabel = new JLabel("(单位：元)");
			lblNewLabel.setBounds(701, 182, 68, 37);
			frame_turtle.getContentPane().add(lblNewLabel);
}


}
