package dao;


import java.sql.*;

/**
 * 该类用于向user表中插入或更新数据
 * @author Anjail
 *
 */


public class SQL {
	// JDBC driver name and database URL
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	//static final String DB_URL = "jdbc:mysql://localhost/teacher2?user=root&password=sck88561430";
	 static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
	 
	 
	 /**
	  * 插入用户名和密码的函数
	  * @param name
	  * @param password
	  */
	 public void dataInsert(String name, String password){

		 double money = 10000.0;
		 String goods ="";
		 Connection conn = null;
		   Statement stmt = null;
		   try{
		      //STEP 2: Register JDBC driver
		      Class.forName("com.mysql.jdbc.Driver");

		      //STEP 3: Open a connection
		      //System.out.println("Connecting to database...");
		      conn = DriverManager.getConnection(DB_URL);

		      //STEP 4: Execute a query
		      //System.out.println("Creating statement...");
		      stmt = conn.createStatement();
		    
		      String sql = "create table  if not exists 2014302580016_user ("
			      		+ "id int unsigned not null auto_increment primary key,"
			      		+ "name char(30) not null,"
			      		
			      		+ "password char(100) not null,"
			      		+"money double not null,"
			      		+"goods varchar(500) not null"
			      		+ ");";
			     
		      stmt.execute(sql);
				 sql = "insert into 2014302580016_user (id ,name,password,money,goods) "
							+ "values("+"NULL,\""+name+"\",\""+password+"\",\""+money+"\",\""+goods+
							"\");";
		    	   

				stmt.execute(sql);
		     // System.out.println(sql);
		   
		      //STEP 6: Clean-up environment
		    
		      stmt.close();
		      conn.close();
		   }catch(SQLException se){
		      //Handle errors for JDBC
		      se.printStackTrace();
		   }catch(Exception e){
		      //Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		            stmt.close();
		      }catch(SQLException se2){
		      }// nothing we can do
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try
	 }

	 
	 /**
	  * 根据用户名对用户的余额和宠物名称更新
	  * @param name
	  * @param money
	  * @param petname
	  */
	 public void dataUpdate(String name,double money,String goods){

		 
		 Connection conn = null;
		   Statement stmt = null;
		   try{
		      //STEP 2: Register JDBC driver
		      Class.forName("com.mysql.jdbc.Driver");

		      //STEP 3: Open a connection
		      //System.out.println("Connecting to database...");
		      conn = DriverManager.getConnection(DB_URL);

		      //STEP 4: Execute a query
		      //System.out.println("Creating statement...");
		      stmt = conn.createStatement();
		    
		      String sql ="update 2014302580016_user set money="+money +" , goods=\""+goods+"\""+"  where name=\""+name+"\";";
			      		
			     
		      stmt.execute(sql);
				
		   
		      //STEP 6: Clean-up environment
		    
		      stmt.close();
		      conn.close();
		   }catch(SQLException se){
		      //Handle errors for JDBC
		      se.printStackTrace();
		   }catch(Exception e){
		      //Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		            stmt.close();
		      }catch(SQLException se2){
		      }// nothing we can do
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try
	 }



}
