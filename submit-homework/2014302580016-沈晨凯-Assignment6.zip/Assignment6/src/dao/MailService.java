package dao;

import java.io.IOException;
import java.util.Date;
import java.util.Properties;
import javax.mail.Address;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;




/**
 * 
 * @author Anjail
 *
 */

public class MailService implements IMailService{
	
	
	final String userName  = "zymvp002@163.com";
	final String password = "997970552";
	 /**
	  * 接收邮件的props文件
	  */
	Properties propsReceive = System.getProperties();
	
	/**
	 * 发送邮件的props文件
	 */
	Properties propsSend = System.getProperties();
	
	/**
	 * 邮件服务器认证
	 */
	MyAuthenticator auth = new MyAuthenticator(userName,password);  
	
	/**
	 * stmp地址
	 */
	final String smtpHost = "smtp.163.com";
	
	/**
	 * imap 地址
	 */
	final String imapHost = "imap.163.com";
	
	/**
	 * 发送邮件会话对象
	 */
	Session sessionSend;
	
	/**
	 * 接收邮件会话对象
	 */
	 Session sessionReceive;
	
	/**
	 * Transport
	 */
	Transport transport;
	
	/**
	 * Store
	 */
	Store store;
	@Override
	public void connect() throws MessagingException {
		// TODO Auto-generated method stub
		
		propsSend.put("mail.smtp.host", smtpHost);
		propsSend.put("mail.smtp.auth","true");
		//propsSend.put("mail.smtp.from", userName);
		
		propsReceive.put("mail.imap.host",imapHost);
		propsReceive.put("mail.store.protocol", "imap");
		
		
		
		
		//完成发送信息的连接
		sessionSend =Session.getInstance(propsSend,auth);
		transport = sessionSend.getTransport("smtp");
		transport.connect();
		
		
		
	}

	@Override
	public void send(String recipient, String subject, Object content)
			throws MessagingException {
		// TODO Auto-generated method stub
		MimeMessage message = new MimeMessage(sessionSend);
		message.setText(content.toString());
		message.setSubject(subject);
		message.setSentDate(new Date());
		
		Address toAddress = new InternetAddress(recipient);
		//设置发件人地址
		message.setFrom(new InternetAddress(userName));
		//System.out.println(auth.getName());
		//设置收件人地址
		message.addRecipient(Message.RecipientType.TO, toAddress);
		//发送邮件
//		try {
//			System.out.println(message.getContent());
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		Transport.send(message);
		
		
	}

	@Override
	public boolean listen() throws MessagingException {
		// TODO Auto-generated method stub
		//auth = new MyAuthenticator();
		sessionReceive = Session.getInstance(propsReceive,auth);
		 store = sessionReceive.getStore("imap");
		store.connect();
		
		
		Folder folder =  store.getFolder("inbox");
		folder.open(Folder.READ_ONLY);
		
	
		if(folder.hasNewMessages())					//	判断是否有新的邮件产生
		{
			folder.close(false);
			
			return true;
		}
		folder.close(false);
		
		return false;
	}

	@Override
	public String getReplyMessageContent(String sender, String subject)
			throws MessagingException, IOException {
		// TODO Auto-generated method stub
		
		String mailContent="";
		Folder folder = store.getFolder("INBOX");
		  folder.open(Folder.READ_ONLY);
		  
		  Message message = folder.getMessage(folder.getMessages().length);					//选取最新收到的一封邮件 即最后一封
		  
		  mailContent+=message.getSubject()+"\n"
			+"邮件的发件人地址是："+sender+"\n"
			+"邮件的内容是："+message.getContent().toString()+"\n";
				
			folder.close(false);
			store.close();
		  
		
		
		return mailContent;
	}
	
	

}


/**
 * 亲自认证，通过手动输入用户名以及密码确认登录
 * @author Anjail
 *
 */


