﻿package dao;



import javax.mail.MessagingException;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;



import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Random;

import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;




public class RegisterGUI {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private String Code;



	/**
	 * Create the application.
	 */
	public RegisterGUI() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 753, 440);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		//确认的按钮事件
		JButton btnNewButton = new JButton("确  认");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String code = textField_3.getText().trim();
				if(code.equals(Code) && (textField_1.getText().trim().equals(textField_2.getText().trim())))			//如果验证码正确 将用户名密码存入数据库
				{
					String username = textField.getText().trim();
					String password = textField_1.getText().trim();
					SQL dataInsert = new SQL();
					dataInsert.dataInsert(username, password);
					
					//执行完一切后 跳转到原本的登录界面
					frame.setVisible(false);
				JOptionPane.showMessageDialog(null, "恭喜你创建成功！登录就送10000元！");
				new LoginGUI();
				}
				else 				//	如果不正确 输出
					{
						JOptionPane.showMessageDialog(null, "验证码有误或两次密码不同，请确认", "验证信息", 2);
					}
				
				
			}
		});
		btnNewButton.setBounds(128, 267, 128, 23);
		frame.getContentPane().add(btnNewButton);
		
		textField = new JTextField();
		textField.setBounds(173, 40, 205, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JPasswordField();
		textField_1.setBounds(173, 81, 205, 21);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("请输入创建的用户名");
		lblNewLabel.setBounds(46, 43, 117, 15);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("输入密码");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setBounds(46, 84, 105, 15);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("确认密码");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2.setBounds(46, 119, 105, 15);
		frame.getContentPane().add(lblNewLabel_2);
		
		textField_2 = new JPasswordField();
		textField_2.setBounds(173, 116, 205, 21);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("验证码");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_3.setBounds(46, 181, 105, 15);
		frame.getContentPane().add(lblNewLabel_3);
		
		textField_3 = new JTextField();
		textField_3.setBounds(173, 178, 205, 21);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
	
		textField_4 = new JTextField();
		textField_4.setBounds(173, 147, 205, 21);
		frame.getContentPane().add(textField_4);
		textField_4.setColumns(10);
		//////////////////
		
		JTextArea textArea = new JTextArea("请填写用户名和密码注册\n并填写正确的邮箱获取验证码\n验证码在邮箱中查看\n谢谢。");
		textArea.setLineWrap(true);				//设置自动换行
		
		JScrollPane jsp = new JScrollPane(textArea);
		jsp.setBounds(433,36, 205, 178);
		jsp.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);//没有这句话不显示滚动条
		
		frame.getContentPane().add(jsp);
		
		JButton btnNewButton_1 = new JButton("获取验证码");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String mailname = textField_4.getText();
				MailService service = new MailService();
				Code = TestRandom.getRandNum(6);
				try {
					service.connect();
				} catch (MessagingException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				try {
					service.send(mailname, "获取验证码", Code);
				} catch (MessagingException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
			}	
	JOptionPane.showMessageDialog(null, "请到邮箱内查看验证码");
	}
		});
		btnNewButton_1.setBounds(128, 223, 128, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel_4 = new JLabel("邮箱帐号");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4.setBounds(97, 144, 54, 15);
		frame.getContentPane().add(lblNewLabel_4);
		
		
	}
	
}

		/**
		 * 获取随机数的验证码
		 * @author Anjail
		 *
		 */
class TestRandom {
	public String getRandStr(int charCount) {
		String charValue = "";
		for (int i = 0; i < charCount; i++){
			char c = (char) (randomInt(0,26)+'a');
			charValue += String.valueOf(c);
		}
		return charValue;
	}
	public static String getRandNum(int charCount) {
		String charValue = "";
		for (int i = 0; i < charCount; i++){
			char c = (char) (randomInt(0,10)+'0');
			charValue += String.valueOf(c);
		}
		return charValue;
	}

	public static int randomInt(int from, int to){
		Random r = new Random();
		return from + r.nextInt(to - from);
	}
}