package dao;





import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;


public class MyAuthenticator extends Authenticator{
	
	String username, password;
	
	public MyAuthenticator(String username, String password) {
		this.username=username;
		this.password=password;
       
    }
	
	 public PasswordAuthentication getPasswordAuthentication() {
		    
		
		   				
		  
		    return new PasswordAuthentication(username, password);
		  }
	 
	 public  String getName()
	 {
		 return username;
	 }
}