package dao;

import pojo.*;

import java.awt.EventQueue;





import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


import java.util.ArrayList;

import javax.swing.JTextArea;
/**
 * 登录界面
 * @author Anjail
 *
 */

public class LoginGUI {

	public static  JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	 static String userName;
	 String password;
	 static double money;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					new LoginGUI();
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LoginGUI() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("宠物商店Login");
		frame.setBounds(100, 100, 819, 439);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setResizable(false);
		
		JLabel label = new JLabel("用户名：");
		label.setFont(new Font("宋体", Font.PLAIN, 15));
		label.setBounds(213, 121, 97, 30);
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("密  码： ");
		label_1.setFont(new Font("宋体", Font.PLAIN, 15));
		label_1.setBounds(213, 190, 97, 30);
		frame.getContentPane().add(label_1);
		
		textField = new JTextField();
		textField.setBounds(290, 126, 131, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JPasswordField();
		textField_1.setBounds(290, 195, 131, 21);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JTextArea textArea = new JTextArea("若没有账号，请先注册。");
		textArea.setWrapStyleWord(true);
		textArea.setToolTipText("");
		textArea.setForeground(new Color(0, 0, 0));
		textArea.setFont(new Font("微软雅黑", Font.PLAIN, 16));
		textArea.setBounds(69, 318, 611, 53);
		frame.getContentPane().add(textArea);
		
		
		
		JButton button = new JButton("登    录");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//创建datareader对象 执行读取函数 存入数组中
				UserData datareader =new UserData();
				ArrayList<User> userData = datareader.read();
				for(User u : userData)
				{
					if(textField.getText().trim().equals(u.getName())){//如果有这个账号
						
						if(textField_1.getText().trim().equals(u.getPassword())){//且如果这个账号对应的密码输入正确
						frame.setVisible(false);
						new StoreGUI();
						userName=u.getName();
						password=u.getPassword();
						money = u.getMoney();
						textArea.setText("登录成功");
						new CartGUI();
						
					}
					else{
						JOptionPane.showMessageDialog(null, "您的账号或密码有误，请核对！", "alert", JOptionPane.ERROR_MESSAGE);
						textArea.setText("您的账号或密码有误，请核对！");
					}
				}
			}
			}
		});
		button.setForeground(Color.DARK_GRAY);
		button.setBounds(323, 253, 93, 23);
		frame.getContentPane().add(button);
		
		JLabel lblNewLabel = new JLabel("欢迎登录宠物商店");
		lblNewLabel.setFont(new Font("微软雅黑", Font.PLAIN, 16));
		lblNewLabel.setBackground(Color.BLUE);
		lblNewLabel.setBounds(262, 41, 159, 38);
		frame.getContentPane().add(lblNewLabel);
		
		
		JButton btnNewButton_1 = new JButton("退  出");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
				
			}
		});
		btnNewButton_1.setFont(new Font("微软雅黑", Font.PLAIN, 14));
		btnNewButton_1.setBounds(458, 252, 93, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel_4 = new JLabel("提示信息");
		lblNewLabel_4.setFont(new Font("微软雅黑", Font.PLAIN, 14));
		lblNewLabel_4.setBounds(81, 289, 87, 15);
		frame.getContentPane().add(lblNewLabel_4);
		
		JButton btnNewButton_2 = new JButton("注  册");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				new RegisterGUI();
			}
		});
		btnNewButton_2.setBounds(202, 252, 93, 23);
		frame.getContentPane().add(btnNewButton_2);
		
		
	}
	public static  String getuserName()
	 {
		 return userName;
	 }
	 
	 public  String getpassword()
	 {
		 return password;
	 }
	 public static double getMoney(){
		 return money;
	 }
}
