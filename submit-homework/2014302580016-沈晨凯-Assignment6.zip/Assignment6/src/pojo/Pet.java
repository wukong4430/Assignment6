package pojo;

public class Pet {
	private String name;
	private String eat;
	private String drink;
	private String live;
	private String hobby;
	private double price;
	
	public Pet(String name ,String eat,String drink,String live,String hobby,double price){
		this.name = name;
		this.eat= eat;
		this.drink = drink;
		this.live = live;
		this.hobby = hobby;
		this.price = price;
	}

//	public Pet (String p){
//		if(p.equals("dog")){
//
//		}
//		if(p.equals("cat")){
//
//		}
//		if(p.equals("turtle")){//乌龟
//
//		}
//		if(p.equals("parrot")){//鹦鹉
//
//		}
//		if(p.equals("hamster")){//仓鼠
//
//		}
//		if(p.equals("squirrel")){//松鼠
//
//		}
//		if(p.equals("rabbit")){
//
//		}
//		if(p.equals("snake")){
//
//		}
//		if(p.equals("lizard")){//蜥蜴
//
//		}
//		if(p.equals("fish")){
//
//		}
//		if(p.equals("myna")){//八哥
//
//		}
//		if(p.equals("canary")){//金丝雀
//
//		}
//		
//		}
	public String getName(){
			return name;
	}
	public String getEat(){
		return eat;
	}
	public String getDrink(){
		return drink;
	}
	public String getLive(){
		return live;
	}
	public String getHobby(){
		return hobby;
	}
	public double getPrice(){
		return price;
	}
}
