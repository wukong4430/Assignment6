package pojo;

public class User {
	//暂时只用到用户名和密码两个参数
	//现在有四个参数， 另外两个是余额和拥有的宠物名字
	private String userName;
	private String password;
	private double money;
	private String goods;
	public User(String userName, String password,double money,String goods)
	{
		this.userName = userName;
		this.password = password;
		this.money = money;
		this.goods = goods;
	}
	
	public String getName(){
		return userName;
	}
	public String getPassword(){
		return password;
	}
	public double getMoney(){
		return money;
	}
	public String getGoods(){
		return goods;
	}
}
