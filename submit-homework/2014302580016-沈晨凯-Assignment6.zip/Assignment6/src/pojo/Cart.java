package pojo;

import java.util.ArrayList;


/**
 * 购物车类
 * @author Anjail
 *
 */
public class Cart {
	private ArrayList<String> petname;
	private ArrayList<Integer> petnumber;

	public Cart (ArrayList<String> petname, ArrayList<Integer> petnumber){
		this.petname = petname;
		this.petnumber =petnumber;

	}
	public ArrayList<String> getPetname(){
		return petname;
	}
	public ArrayList<Integer> getPetnumber(){
		return petnumber;
	}
	
	
//	private ArrayList<Pet> pet;
//	
//	public Cart(ArrayList<Pet> pet){
//		this.pet=pet;
//	}
//	public ArrayList<Pet> getPet(){
//		return pet;
//	}
}
