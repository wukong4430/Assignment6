/*
SQLyog Professional v12.08 (64 bit)
MySQL - 5.7.9-log : Database - num_1
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `2014302580015_pet` */

CREATE TABLE `2014302580015_pet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `eat` varchar(255) NOT NULL DEFAULT '',
  `drink` varchar(255) NOT NULL DEFAULT '',
  `live` varchar(255) NOT NULL DEFAULT '',
  `hobby` varchar(255) NOT NULL DEFAULT '',
  `prize` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

/*Data for the table `2014302580015_pet` */

insert  into `2014302580015_pet`(`id`,`name`,`eat`,`drink`,`live`,`hobby`,`prize`) values (1,'dog','bone','water','ground','play',150),(2,'cat','fish','milk','roof','hug',250),(3,'turtle','fish,shrimp','sea water','sea water','bask',100),(4,'parrot','nuts,seeds','water','tree','fly',200),(5,'hamster','Sunflower seed','water','corner','eat',250),(6,'squirrel','pine cone','water','tree hole,underground','play',75),(7,'rabbit','carrot','water','grassland,underground','eat',100),(8,'snake','mouse','water','hole','bask',350),(9,'lizard','bug','water','tree','bask',400),(10,'fish','aquatic plant','water','water','swim',200),(11,'myna','earthworm','water','tree','fly',175),(12,'canary','millet','water','tree','sing',275);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
